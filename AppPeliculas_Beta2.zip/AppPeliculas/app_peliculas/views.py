from django.http import JsonResponse
from django.shortcuts import render
import requests
from .models import Movie
from datetime import datetime
import pandas as pd
import logging
import json

# Configurar el registro de depuración
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def index(request):
    return render(request, 'index.html')

def extract_titles_from_response(raw_text):
    """Extrae títulos de películas del texto crudo de la respuesta de llama3."""
    titles = []
    try:
        # Procesar la respuesta JSON de llama3
        responses = raw_text.strip().split('\n')
        for response in responses:
            try:
                json_response = json.loads(response)
                title_part = json_response.get('response', '').strip()
                if title_part:
                    if titles and not titles[-1].endswith(';'):
                        titles[-1] += ' ' + title_part
                    else:
                        titles.append(title_part)
            except json.JSONDecodeError:
                logger.warning(f"No se pudo decodificar la respuesta JSON: {response}")

        # Procesar los títulos
        processed_titles = []
        current_title = ''
        for title in titles:
            if title.endswith(';'):
                current_title += title[:-1].strip()
                processed_titles.append(current_title.strip())
                current_title = ''
            else:
                current_title += title + ' '
        
        if current_title:
            processed_titles.append(current_title.strip())

        logger.info(f'Títulos extraídos: {processed_titles}')
        return processed_titles
    except Exception as e:
        logger.error(f'Error al extraer títulos: {str(e)}')
        return []

def search_movies(request):
    query = request.GET.get('query', '')
    if not query:
        return JsonResponse({'error': 'No se proporcionó una consulta de búsqueda.', 'movies': [], 'recommendations': ''}, status=400)

    try:
        # Paso 1: Usar llama3 para obtener una lista de títulos de películas en inglés separados por punto y coma
        llama_response = requests.post('http://localhost:11434/api/generate', json={
            'model': 'llama3',
            'prompt': f"Devuelve una lista de películas con títulos en inglés que corresponda a esta petición: '{query}'. Da los nombres separados por punto y coma, sin ningún otro contexto."
        })
        llama_response.raise_for_status()
        raw_text = llama_response.text
        logger.info(f'Respuesta cruda de llama3: {raw_text}')

        # Extraer y procesar los títulos
        movie_titles = extract_titles_from_response(raw_text)

        if not movie_titles:
            logger.error('No se encontraron títulos válidos de películas.')
            return JsonResponse({'error': 'No se encontraron títulos válidos de películas.', 'movies': [], 'recommendations': ''}, status=400)

        # Paso 2: Consultar la API de TMDb para cada título y recolectar los detalles de las películas
        api_key = '99eab6190f078a2ea8ca68681266d074'
        movie_details = []

        for title in movie_titles:
            if not title:
                continue
            url = f'https://api.themoviedb.org/3/search/movie?query={requests.utils.quote(title)}&api_key={api_key}&language=en-US'
            try:
                response = requests.get(url)
                response.raise_for_status()
                data = response.json()
                logger.info(f'Respuesta cruda de TMDb para "{title}": {data}')
                results = data.get('results', [])
                if results:
                    movie = results[0]
                    movie_details.append({
                        'title': movie.get('title', ''),
                        'overview': movie.get('overview', ''),
                        'release_date': movie.get('release_date', ''),
                        'tmdb_id': movie.get('id', '')
                    })
            except requests.RequestException as e:
                logger.error(f'Error en la solicitud a la API de TMDb: {str(e)}')
                continue

        # Paso 3: Guardar temporalmente los resultados en un DataFrame
        df = pd.DataFrame(movie_details)
        logger.info(f'Detalles de películas recopilados: {df}')

        # Imprimir el DataFrame en los logs para depuración
        logger.info("DataFrame de detalles de películas:")
        logger.info(df.to_string())

        # Paso 4: Registrar en la base de datos solo las películas que no existen
        for _, row in df.iterrows():
            title = row['title']
            overview = row['overview']
            release_date = row['release_date']
            tmdb_id = row['tmdb_id']

            if release_date:
                try:
                    release_date = datetime.strptime(release_date, '%Y-%m-%d').date()
                except ValueError:
                    release_date = None
            else:
                release_date = None

            try:
                Movie.objects.update_or_create(
                    tmdb_id=tmdb_id,
                    defaults={
                        'title': title,
                        'overview': overview,
                        'release_date': release_date
                    }
                )
            except Exception as e:
                logger.error(f'Error al guardar la película {title}: {str(e)}')

        # Paso 5: Mostrar los resultados en forma de lista
        movie_explanations = [f"Título: {row['title']}\nDescripción: {row['overview']}\nFecha de estreno: {row['release_date']}\n" for _, row in df.iterrows()]

        return JsonResponse({
            'movies': movie_explanations,
            'recommendations': ''
        })

    except Exception as e:
        logger.error(f'Error inesperado: {str(e)}')
        return JsonResponse({
            'error': f'Error inesperado: {str(e)}',
            'movies': [],
            'recommendations': ''
        }, status=500)
