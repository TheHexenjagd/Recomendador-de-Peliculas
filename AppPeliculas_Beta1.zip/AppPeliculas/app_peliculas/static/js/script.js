// Datos de ejemplo de películas
const peliculas = [
    { titulo: 'Inception', descripcion: 'Una película de ciencia ficción sobre los sueños.' },
    { titulo: 'The Matrix', descripcion: 'Una película de ciencia ficción sobre la realidad virtual.' },
    { titulo: 'Titanic', descripcion: 'Una historia romántica basada en hechos reales.' },
    { titulo: 'The Godfather', descripcion: 'Una película sobre la mafia italiana.' },
];

// Función para buscar películas basadas en la consulta
function buscarPeliculas() {
    const query = document.getElementById('query').value.toLowerCase(); // Obtener la consulta y convertirla a minúsculas
    const resultados = document.getElementById('resultados');
    
    const recomendaciones = peliculas.filter(pelicula => 
        pelicula.titulo.toLowerCase().includes(query) ||
        pelicula.descripcion.toLowerCase().includes(query)
    );
    
    resultados.innerHTML = '';
    if (recomendaciones.length > 0) {
        recomendaciones.forEach(pelicula => {
            const peliculaDiv = document.createElement('div');
            peliculaDiv.innerHTML = `<h3>${pelicula.titulo}</h3><p>${pelicula.descripcion}</p>`;
            resultados.appendChild(peliculaDiv);
        });
    } else {
        resultados.innerHTML = '<p>No se encontraron recomendaciones.</p>';
    }
}

// Agregar evento para escuchar el submit del formulario y prevenir el comportamiento por defecto
document.getElementById('query').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        buscarPeliculas();
    }
});