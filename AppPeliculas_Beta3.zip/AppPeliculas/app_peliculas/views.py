from django.http import JsonResponse
from django.shortcuts import render
import requests
from .models import Movie
from datetime import datetime
import pandas as pd
import logging
import json

# Configurar el registro de depuración
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

def index(request):
    return render(request, 'index.html')

def extract_titles_from_response(raw_text):
    """Extrae títulos de películas del texto crudo de la respuesta de llama3."""
    try:
        # Reemplazar secuencias de escape y normalizar saltos de línea
        cleaned_text = raw_text.replace('\\n', '\n').replace('\\u0026', '&')

        # Extraer el contenido relevante del campo 'response'
        if 'response' in cleaned_text:
            # Extraer solo el contenido dentro del campo 'response'
            response_content = cleaned_text.split('response":"')[1].split('"done":')[0]

            # Reemplazar secuencias de escape restantes
            response_content = response_content.replace('\\n', '\n').replace('\\u0026', '&')

            # Dividir la respuesta limpiada por saltos de línea y limpiar espacios adicionales
            titles = [title.strip() for title in response_content.strip().split('\n') if title.strip()]
        else:
            # Si no se encuentra el campo 'response', dividir el texto por saltos de línea directamente
            titles = [title.strip() for title in cleaned_text.strip().split('\n') if title.strip()]

        # Eliminar cualquier título vacío y procesar los títulos
        processed_titles = [title for title in titles if title]

        logger.info(f'Títulos extraídos: {processed_titles}')
        return processed_titles
    except Exception as e:
        logger.error(f'Error al extraer títulos: {str(e)}')
        return []

def search_movies(request):
    query = request.GET.get('query', '')
    if not query:
        return JsonResponse({'error': 'No se proporcionó una consulta de búsqueda.', 'movies': [], 'recommendations': ''}, status=400)

    try:
        # Paso 1: Usar llama3 para obtener una lista de títulos de películas en inglés separados por línea
        llama_response = requests.post('http://localhost:11434/api/generate', json={
            'model': 'llama3',
            "stream": False,
            'prompt': f"Devuelve una lista de películas con títulos en inglés que corresponda a esta petición: '{query}'. Cada título debe estar en una línea separada, sin ningún otro tipo de texto o separador. Sin fechas ni otros datos."
        })
        llama_response.raise_for_status()
        raw_text = llama_response.text
        logger.info(f'Respuesta cruda de llama3: {raw_text}')

        # Extraer y procesar los títulos
        movie_titles = extract_titles_from_response(raw_text)

        if not movie_titles:
            logger.error('No se encontraron títulos válidos de películas.')
            return JsonResponse({'error': 'No se encontraron títulos válidos de películas.', 'movies': [], 'recommendations': ''}, status=400)

        # Paso 2: Consultar la API de TMDb para cada título y recolectar los detalles de las películas
        api_key = '99eab6190f078a2ea8ca68681266d074'
        movie_details = []

        for title in movie_titles:
            if not title:
                continue
            url = f'https://api.themoviedb.org/3/search/movie?query={requests.utils.quote(title)}&api_key={api_key}&language=en-US'
            try:
                response = requests.get(url)
                response.raise_for_status()
                data = response.json()
                logger.info(f'Respuesta cruda de TMDb para "{title}": {data}')
                results = data.get('results', [])
                if results:
                    movie = results[0]
                    movie_details.append({
                        'title': movie.get('title', ''),
                        'overview': movie.get('overview', ''),
                        'release_date': movie.get('release_date', ''),
                        'tmdb_id': movie.get('id', '')
                    })
            except requests.RequestException as e:
                logger.error(f'Error en la solicitud a la API de TMDb: {str(e)}')
                continue

        # Paso 3: Guardar temporalmente los resultados en un DataFrame
        df = pd.DataFrame(movie_details)
        logger.info(f'Detalles de películas recopilados: {df}')

        # Imprimir el DataFrame en los logs para depuración
        logger.info("DataFrame de detalles de películas:")
        logger.info(df.to_string())

        # Paso 4: Registrar en la base de datos solo las películas que no existen
        for _, row in df.iterrows():
            title = row['title']
            overview = row['overview']
            release_date = row['release_date']
            tmdb_id = row['tmdb_id']

            if release_date:
                try:
                    release_date = datetime.strptime(release_date, '%Y-%m-%d').date()
                except ValueError:
                    release_date = None
            else:
                release_date = None

            try:
                Movie.objects.update_or_create(
                    tmdb_id=tmdb_id,
                    defaults={
                        'title': title,
                        'overview': overview,
                        'release_date': release_date
                    }
                )
            except Exception as e:
                logger.error(f'Error al guardar la película {title}: {str(e)}')

        # Paso 5: Mostrar los resultados en forma de lista
        movie_explanations = [f"Título: {row['title']}\nDescripción: {row['overview']}\nFecha de estreno: {row['release_date']}\n" for _, row in df.iterrows()]

        return JsonResponse({
            'movies': movie_explanations,
            'recommendations': ''
        })

    except Exception as e:
        logger.error(f'Error inesperado: {str(e)}')
        return JsonResponse({
            'error': f'Error inesperado: {str(e)}',
            'movies': [],
            'recommendations': ''
        }, status=500)
